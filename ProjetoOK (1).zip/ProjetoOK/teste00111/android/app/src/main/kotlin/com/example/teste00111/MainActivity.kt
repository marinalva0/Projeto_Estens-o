package com.example.teste00111

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
